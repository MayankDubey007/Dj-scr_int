from django.contrib import admin
from .models import Quotes

admin.site.register(Quotes)

